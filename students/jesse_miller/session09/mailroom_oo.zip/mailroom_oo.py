#!/usr/bin/env python3
'''
Here I go again, on my own.
'''
from cli_main import Menus

if __name__ == "__main__":
    Menus.main()
